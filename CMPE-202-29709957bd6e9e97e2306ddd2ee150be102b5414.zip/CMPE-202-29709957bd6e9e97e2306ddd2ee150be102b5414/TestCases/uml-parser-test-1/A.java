 

import java.util.Collection;

public class A {
 
	private int x;
	 
	private int[] y;
	 
	private Collection<B> b;
	 
	private C c;
	 
	private Collection<D> d;
	 
}
 
