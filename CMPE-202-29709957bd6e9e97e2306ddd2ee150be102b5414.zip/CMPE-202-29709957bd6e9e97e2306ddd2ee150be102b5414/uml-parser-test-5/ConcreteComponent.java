
public class ConcreteComponent implements Component {

	public String operation() {
		return "Hello World!";
	}

}
