 

public interface A1 {
 
}
 
