
public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TheEconomy E = new TheEconomy();
		Optimist O = new Optimist();
		//Pessimist P= new Pessimist();
	
		E.setState("The price of gas is $5.00/gal");
		
		E.setState("another ipad tomo");
	
		
		

	}

}
