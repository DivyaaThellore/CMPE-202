
public class Optimist {
	
	
	public void display(String state)
	{
		if( state.length()<20)
			System.out.println(" Great! another ipad");
		else
		System.out.println(" This is one paise lower");
	}
	
}
